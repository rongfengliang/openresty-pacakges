#!/bin/bash
bundle exec nchan-sub "$@"
