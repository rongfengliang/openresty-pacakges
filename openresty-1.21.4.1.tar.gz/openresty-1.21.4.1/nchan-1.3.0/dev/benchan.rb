#!/bin/bash
bundle exec nchan-benchmark "$@"
