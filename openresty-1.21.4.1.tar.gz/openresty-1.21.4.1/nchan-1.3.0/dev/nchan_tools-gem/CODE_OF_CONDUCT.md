In the spirit of inclusiveness, cooperation and community, this software is 
distributed with the strictly enforced CYHTFYW Code of Conduct. Failure to 
comply with this code may result in punitive action and loss of privilege.

## CYHTFYW Code of Conduct:

1. Conduct yourself however the fuck you want.
