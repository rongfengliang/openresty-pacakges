module NchanTools
  VERSION = "0.1.12"
end
