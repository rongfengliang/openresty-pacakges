#!/bin/bash
bundle exec nchan-pub "$@"
