#include <util/nchan_benchmark.h>

subscriber_t *benchmark_subscriber_create(nchan_benchmark_t *bench);
