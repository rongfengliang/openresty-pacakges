import _ from './recursive_relative.js';
export default 42;
