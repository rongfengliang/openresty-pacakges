
/*
 * Copyright (C) Dmitry Volyntsev
 * Copyright (C) NGINX, Inc.
 */

#ifndef _NJS_JSON_H_INCLUDED_
#define _NJS_JSON_H_INCLUDED_


extern const njs_object_init_t  njs_json_object_init;


#endif /* _NJS_JSON_H_INCLUDED_ */
